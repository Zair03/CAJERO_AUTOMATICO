import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CajeroAutomatico {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // ==========================================
        // CREACIÓN DE LA CUENTA
        // ==========================================

        Cuenta cuenta = new Cuenta(
                1001,
                "Ana Pérez",
                "1234",
                500.0
        );

        // Lista para guardar movimientos
        List<Movimiento> movimientos = new ArrayList<>();

        // ==========================================
        // TÍTULO
        // ==========================================

        System.out.println(
                "=== NUEVO PERÚ BANK - CAJERO AUTOMÁTICO ==="
        );

        System.out.println();

        // ==========================================
        // INICIO DE SESIÓN
        // ==========================================

        System.out.print("Ingrese su número de cuenta: ");
        int numeroCuenta = scanner.nextInt();

        System.out.print("Ingrese su contraseña: ");
        String password = scanner.next();

        // ==========================================
        // VALIDAR CUENTA
        // ==========================================

        if (numeroCuenta != cuenta.getNumero()
                || !password.equals(cuenta.getPassword())) {

            System.out.println();
            System.out.println("Cuenta o contraseña incorrecta.");

            scanner.close();
            return;
        }

        // ==========================================
        // BIENVENIDA
        // ==========================================

        System.out.println();
        System.out.println(
                "Bienvenido(a), " + cuenta.getTitular()
        );

        int opcion;

        // ==========================================
        // MENÚ
        // ==========================================

        do {

            System.out.println();
            System.out.println("Seleccione una opción:");
            System.out.println("1. Depósito");
            System.out.println("2. Retiro");
            System.out.println("3. Consulta de saldo");
            System.out.println("4. Salir");

            System.out.print("Opción: ");
            opcion = scanner.nextInt();

            // ======================================
            // DEPÓSITO
            // ======================================

            if (opcion == 1) {

                System.out.print(
                        "Ingrese el monto a depositar: "
                );

                double monto = scanner.nextDouble();

                if (monto > 0) {

                    cuenta.depositar(monto);

                    movimientos.add(
                            new Movimiento(
                                    "DEPÓSITO",
                                    cuenta.getNumero(),
                                    monto,
                                    cuenta.getSaldo()
                            )
                    );

                    System.out.println(
                            "Depósito realizado correctamente."
                    );

                    System.out.printf(
                            "Nuevo saldo: S/ %.1f%n",
                            cuenta.getSaldo()
                    );

                } else {

                    System.out.println(
                            "Monto inválido."
                    );
                }
            }

            // ======================================
            // RETIRO
            // ======================================

            else if (opcion == 2) {

                System.out.print(
                        "Ingrese el monto a retirar: "
                );

                double monto = scanner.nextDouble();

                if (cuenta.retirar(monto)) {

                    movimientos.add(
                            new Movimiento(
                                    "RETIRO",
                                    cuenta.getNumero(),
                                    monto,
                                    cuenta.getSaldo()
                            )
                    );

                    System.out.println(
                            "Retiro realizado correctamente."
                    );

                    System.out.printf(
                            "Nuevo saldo: S/ %.1f%n",
                            cuenta.getSaldo()
                    );

                } else {

                    System.out.println(
                            "No se puede realizar el retiro."
                    );
                }
            }

            // ======================================
            // CONSULTA DE SALDO
            // ======================================

            else if (opcion == 3) {

                movimientos.add(
                        new Movimiento(
                                "CONSULTA",
                                cuenta.getNumero(),
                                0,
                                cuenta.getSaldo()
                        )
                );

                System.out.printf(
                        "Su saldo actual es: S/ %.1f%n",
                        cuenta.getSaldo()
                );
            }

            // ======================================
            // SALIR
            // ======================================

            else if (opcion == 4) {

                System.out.println();
                System.out.println(
                        "Gracias por usar el cajero automático."
                );

                System.out.println(
                        "¡Hasta pronto!"
                );
            }

            // ======================================
            // OPCIÓN INCORRECTA
            // ======================================

            else {

                System.out.println(
                        "Opción no válida."
                );
            }

        } while (opcion != 4);

        // ==========================================
        // TABLA DE MOVIMIENTOS
        // ==========================================

        System.out.println();

        System.out.println(
                "=== MOVIMIENTOS DE LA CUENTA ==="
        );

        System.out.printf(
                "%-14s %-10s %-15s %-15s%n",
                "TIPO",
                "CUENTA",
                "MONTO",
                "SALDO"
        );

        System.out.println(
                "------------------------------------------------------------"
        );

        // ==========================================
        // MOSTRAR MOVIMIENTOS
        // ==========================================

        for (Movimiento movimiento : movimientos) {

            if (movimiento.getTipo().equals("CONSULTA")) {

                System.out.printf(
                        "%-14s %-10d %-15s S/ %.1f%n",
                        movimiento.getTipo(),
                        movimiento.getCuenta(),
                        "-",
                        movimiento.getSaldo()
                );

            } else {

                System.out.printf(
                        "%-14s %-10d S/ %-11.1f S/ %.1f%n",
                        movimiento.getTipo(),
                        movimiento.getCuenta(),
                        movimiento.getMonto(),
                        movimiento.getSaldo()
                );
            }
        }

        // ==========================================
        // FINAL
        // ==========================================

        System.out.println(
                "------------------------------------------------------------"
        );

        System.out.println(
                "Presione una tecla para continuar . . ."
        );

        scanner.close();
    }
}