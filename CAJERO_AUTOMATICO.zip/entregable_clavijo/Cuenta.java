public class Cuenta {

    private int numero;
    private String titular;
    private String password;
    private double saldo;

    public Cuenta(int numero, String titular, String password, double saldo) {
        this.numero = numero;
        this.titular = titular;
        this.password = password;
        this.saldo = saldo;
    }

    public int getNumero() {
        return numero;
    }

    public String getTitular() {
        return titular;
    }

    public String getPassword() {
        return password;
    }

    public double getSaldo() {
        return saldo;
    }

    public void depositar(double monto) {
        saldo = saldo + monto;
    }

    public boolean retirar(double monto) {

        if (monto > 0 && monto <= saldo) {
            saldo = saldo - monto;
            return true;
        }

        return false;
    }
}