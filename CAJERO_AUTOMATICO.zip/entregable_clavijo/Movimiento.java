public class Movimiento {

    private String tipo;
    private int cuenta;
    private double monto;
    private double saldo;

    public Movimiento(String tipo, int cuenta, double monto, double saldo) {
        this.tipo = tipo;
        this.cuenta = cuenta;
        this.monto = monto;
        this.saldo = saldo;
    }

    public String getTipo() {
        return tipo;
    }

    public int getCuenta() {
        return cuenta;
    }

    public double getMonto() {
        return monto;
    }

    public double getSaldo() {
        return saldo;
    }
}